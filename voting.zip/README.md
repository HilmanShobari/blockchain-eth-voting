# Voting React App

This is a voting react App.
It also adds some basic UI to the transaction progress.

In order to run this application run these commands:

1. Install dependencies:
```
npm install
```

2. Make sure you are using Polygon Mumbai Network

3. Launch the Voting React App:
```
npm run dev
```

if you need to add endDate validation to pick random Voter uncomment the Voting.sol in line 100